﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SCI.Class1;

namespace SCI
{
	// Sensor especializado en detectar incrementos peligrosos de temperatura.
	// Hereda del sensor base y establece su umbral crítico por defecto.
	public class SensorTemperatura : Sensor
	{
		// Constructor del sensor de temperatura.
		// Se asigna un nombre por defecto y un umbral de 70°C,
		// considerado zona de posible inicio de incendio.
		public SensorTemperatura(int id) : base(id, "Sensor de Temperatura", 70)
		{
			// No requiere más configuraciones.
			// La lógica principal se ejecuta en la clase base Sensor.
		}
	}
}

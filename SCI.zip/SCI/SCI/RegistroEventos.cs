﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCI
{
	
	// Clase estática encargada de registrar todos los eventos importantes del sistema.
	// Cada acción realizada (alarma, reset, desactivación, lectura, etc.)
	// queda almacenada con fecha y hora.
	public static class RegistroEventos
	{
		// Lista que almacena todo el historial de eventos del sistema.
		public static List<string> Eventos { get; } = new List<string>();

		/// Registra un nuevo evento en el historial.
		/// Incluye automáticamente la fecha y hora.
		public static void Registrar(string texto)
		{
			string evento = $"[{DateTime.Now}] {texto}";
			Eventos.Add(evento);
		}
	}
}


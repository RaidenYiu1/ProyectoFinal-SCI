﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SCI.Class1;

namespace SCI
{
    public class PanelControl
	{
		public Sensor[] Sensores { get; } // Arreglo de sensores del sistema
		private Random random = new Random(); // Generador de lecturas simuladas

		public PanelControl()
		{
			// Inicialización de sensores instalados
			Sensores = new Sensor[]
			{
				new SensorHumo(1), // Sensor ID 1
				new SensorTemperatura(2), // Sensor ID 2
				new SensorHumo(3) // Sensor ID 3
			};
		}

		/// Muestra el estado actual de todos los sensores.
		public void MostrarSensores()
		{
			Console.WriteLine("=== ESTADO DE SENSORES ===");
			foreach (var s in Sensores)
			{
				Console.WriteLine($"ID {s.Id} - {s.Nombre} | Lectura: {s.Lectura} | Estado: {s.Estado}");
			}
		}

		// Simula una lectura automática para todos los sensores.
		public void SimularLecturas()
		{
			foreach (var s in Sensores)
			{
				// Valores aleatorios entre 0 y 120 para humo o temperatura
				int valor = random.Next(0, 120);
				s.SimularLectura(valor);
			}

			RegistroEventos.Registrar("Simulación de lectura ejecutada.");
		}

		/// Activa manualmente la alarma de un sensor según su ID.
		public void ActivarAlarmaManual(int id)
		{
			var s = Sensores.FirstOrDefault(x => x.Id == id);
			if (s == null) return;

			s.ActivarAlarma();
		}

		// Resetea un sensor para que vuelva a estado normal.
		public void ResetearSensor(int id)
		{
			var s = Sensores.FirstOrDefault(x => x.Id == id);
			if (s == null) return;

			s.Resetear();
		}

		// Desactiva un sensor completamente
		public void DesactivarSensor(int id)
		{
			var s = Sensores.FirstOrDefault(x => x.Id == id);
			if (s == null) return;

			s.Desactivar();
		}

		// Muestra todos los eventos registrados en el historial.
		public void MostrarHistorial()
		{
			Console.WriteLine("=== HISTORIAL DE EVENTOS ===");
			foreach (var e in RegistroEventos.Eventos)
				Console.WriteLine(e);
		}
	}
}
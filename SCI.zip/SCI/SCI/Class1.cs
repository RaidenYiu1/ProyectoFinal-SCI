﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCI
{
    public class Class1
    {
		// Estados posibles del sensor
		public enum EstadoSensor
		{
			Normal,
			Alarma,
			Desactivado
		}

		// Clase abstracta que sirve como base para los sensores del sistema
		public abstract class Sensor
		{
			public int Id { get; } // Identificador único
			public string Nombre { get; } // Nombre del sensor
			public int Umbral { get; protected set; } // Valor crítico para activar alarma
			public int Lectura { get; protected set; } // Último valor leído
			public EstadoSensor Estado { get; protected set; }// Estado actual del sensor

			// Constructor
			public Sensor(int id, string nombre, int umbral)
			{
				Id = id;
				Nombre = nombre;
				Umbral = umbral;
				Estado = EstadoSensor.Normal; // Estado inicial
			}
			// Simulación de lectura (permite ingreso manual)
			public virtual void SimularLectura(int valor)
			{
				// No permite lectura si está desactivado
				if (Estado == EstadoSensor.Desactivado)
				{
					RegistroEventos.Registrar($"Intento de lectura en sensor DESACTIVADO: {Nombre}");
					return;
				}

				Lectura = valor;


				// Si supera el umbral activar alarma
				if (Lectura >= Umbral)
					ActivarAlarma();
				else
				{
					Estado = EstadoSensor.Normal;
					RegistroEventos.Registrar($"Lectura normal: {Nombre} = {Lectura}");
				}
			}

			// Activa la alarma del sensor
			public virtual void ActivarAlarma()
			{
				Estado = EstadoSensor.Alarma;
				RegistroEventos.Registrar($"¡¡ALERTA!! Sensor {Nombre} (ID {Id}) en ALARMA");

				// Alarma sonora
				// beep fuerte
				for (int i = 0; i < 2; i++)
				{
					Console.Beep(1000, 200);
					Console.Beep(1200, 200);
				}
			}

			// Resetea el sensor a estado normal
			public void Resetear()
			{
				Estado = EstadoSensor.Normal;
				RegistroEventos.Registrar($"Sensor {Nombre} reseteado");

				Console.Beep(500, 100); // beep suave
			}

			// Desactiva el sensor
			public void Desactivar()
			{
				Estado = EstadoSensor.Desactivado;
				RegistroEventos.Registrar($"Sensor {Nombre} desactivado");

				Console.Beep(400, 100); // beep suave grave
			}
		}
	}
}


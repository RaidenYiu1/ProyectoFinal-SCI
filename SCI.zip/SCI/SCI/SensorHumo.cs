﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SCI.Class1;

namespace SCI
{
	// Sensor especializado en detectar partículas de humo en el ambiente.
	// Hereda del sensor base y fija automáticamente un umbral de riesg
	public class SensorHumo : Sensor
	{
		// Constructor del sensor de humo.
		// Asigna un nombre por defecto y un umbral de 50,
		// considerado nivel peligroso de concentración de humo.
		public SensorHumo(int id) : base(id, "Sensor de Humo", 50)
		{
			// No se requiere lógica adicional:
			// La evaluación de lectura y activación de alarma está en la clase base Sensor.
		}
	}
}

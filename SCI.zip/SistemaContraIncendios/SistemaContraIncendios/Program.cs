﻿// Proyecto final _Alumno
//JHONATAN DANIEL CHUQUIRUNA RODRIGUEZ

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SCI; // Importamos la biblioteca de sensores
using System.Threading.Tasks;


namespace SistemaContraIncendios
{
	internal class Program
	// Punto de entrada del sistema contra incendios.
	// Muestra un menú de opciones para interactuar con los sensores.
	{
		static void Main(string[] args)
		{
			// Datos de identificación 
			Console.WriteLine("Daniel Chuquiruna Rodriguez");
			Console.WriteLine(DateTime.Now.AddHours(0));
			// Se crea el panel de control
			PanelControl panel = new PanelControl();
			while (true)
            {
				// Limpia pantalla y muestra menú principal
				Console.Clear();
				Console.WriteLine("=== SISTEMA CONTRA INCENDIOS ===");
				Console.WriteLine("1. Ver Sensores");
				Console.WriteLine("2. Simular lectura de sensores");
				Console.WriteLine("3. Activar alarma de un sensor");
				Console.WriteLine("4. Resetear sensor");
				Console.WriteLine("5. Desactivar sensor");
				Console.WriteLine("6. Ver historial de eventos");
				Console.WriteLine("0. Salir");
				Console.Write("Seleccione una opción: ");
				string opcion = Console.ReadLine();
				switch (opcion)
				{
					case "1":
						Console.WriteLine("\n>> Mostrando el estado actual de todos los sensores...");
						panel.MostrarSensores();
						Console.WriteLine("Sistema Contra Incenios");
						Console.WriteLine(DateTime.Now.AddHours(0)); break;

					case "2":
						Console.WriteLine("\n>> Simulando lecturas aleatorias en TODOS los sensores...");
						Console.WriteLine(">> Si una lectura supera su umbral, se activará la alarma automáticamente.");
						panel.SimularLecturas();
						Console.WriteLine(">> Lecturas simuladas correctamente.");
						Console.WriteLine("Sistema Contra Incenios");
						Console.WriteLine(DateTime.Now.AddHours(0)); break;

					case "3":
						Console.Write("\nIngrese el ID del sensor para activar su alarma: ");
						int idA = int.Parse(Console.ReadLine());
						Console.WriteLine($">> Activando alarma del sensor {idA} manualmente...");
						panel.ActivarAlarmaManual(idA);
						Console.WriteLine("Sistema Contra Incenios");
						Console.WriteLine(DateTime.Now.AddHours(0)); break;

					case "4":
						Console.Write("\nIngrese el ID del sensor a resetear: ");
						int idR = int.Parse(Console.ReadLine());
						Console.WriteLine($">> Reseteando el sensor {idR} a estado NORMAL...");
						panel.ResetearSensor(idR);
						Console.WriteLine("Sistema Contra Incenios");
						Console.WriteLine(DateTime.Now.AddHours(0)); break;
					case "5":
						Console.Write("\nIngrese el ID del sensor a desactivar: ");
						int idD = int.Parse(Console.ReadLine());
						Console.WriteLine($">> Desactivando el sensor {idD}...");
						panel.DesactivarSensor(idD);
						Console.WriteLine("Sistema Contra Incenios");
						Console.WriteLine(DateTime.Now.AddHours(0)); break;

					case "6":
						Console.WriteLine("\n>> Mostrando historial de eventos del sistema...");
						panel.MostrarHistorial();
						Console.WriteLine("Sistema Contra Incenios");
						Console.WriteLine(DateTime.Now.AddHours(0)); break; 

					case "0":
						Console.WriteLine("\n>> Cerrando el sistema...");
						return;

					default:
						Console.WriteLine("\n>> Opción no válida. Intente nuevamente.");
						Console.WriteLine("Sistema Contra Incenios");
						Console.WriteLine(DateTime.Now.AddHours(0));break;

				}

				Console.WriteLine("\nPresione cualquier tecla para continuar...");
				Console.ReadKey();
			}
		}
	}

}

			
		
    

